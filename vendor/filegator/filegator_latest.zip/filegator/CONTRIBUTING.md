## Contributing to FileGator

Please note we have a code of conduct, please follow it in all your interactions with the project.

- Before starting to write code, talk to a maintainer and discuss proposed changes
- File an issue before submitting a pull request
- Please make sure continuous integration passes

## Where to report bugs?

- Please report all bugs in this repository's issues tracker.
